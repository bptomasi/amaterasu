#include "amaterasu.h"

struct Amaterasu Amaterasu;