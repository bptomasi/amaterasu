#ifndef REGISTRATION_H
#define REGISTRATION_H

#include "common.h"
#include "callbacks.h"




#endif  /* REGISTRATION_H */
